from __future__ import annotations

from pathlib import Path

from corpus_loader import load_corpus
from classifier import classify_request_type
from escalation import escalation_guard
from intent import detect_multi_intent
from retriever import Retriever, Hit
from router import area_override, route_company
from sanitizer import sanitize_row
from safety import detect_harmful
from validator import validate_output

# ---------------------------------------------------------------------------
# Pattern groups — generalised matching so unseen phrasings still route
# correctly without needing a new hard-coded branch for every variation.
# ---------------------------------------------------------------------------
_BEDROCK_TERMS = (
    "bedrock", "aws claude", "anthropic via aws", "model invocation failed",
    "aws bedrock", "via bedrock", "bedrock endpoint", "bedrock integration",
)
_TRAVEL_CARD_TERMS = (
    "bloquée", "bloque", "voyage", "tarjeta", "ma carte",
    "abroad", "overseas", "travelling", "traveling", "foreign transaction",
    "international transaction", "card abroad",
)
_INACTIVITY_TERMS = (
    "inactivity", "inactive", "kicked out", "sent back to the hr lobby",
    "session expired", "lobby", "automatically logged", "timed out",
)
_REMOVAL_TERMS = (
    "remove an interviewer", "employee has left", "remove them from",
    "remove them", "deactivate user", "left the company", "employee left",
    "remove user", "revoke access",
)
_RESUME_TERMS = (
    "resume builder", "build resume", "create resume", "resume tool",
)
_CRAWL_TERMS = (
    "stop crawling", "crawl", "crawler", "web crawl", "block anthropic",
    "block crawler", "disallow crawl",
)
_DATA_IMPROVE_TERMS = (
    "data to improve", "training data", "model improvement", "use my data",
    "use my chats", "data retention", "how long will the data",
)


def _match(text: str, patterns: tuple[str, ...]) -> bool:
    """Return True if any pattern appears in the lowercased text."""
    return any(p in text for p in patterns)


class SupportAgent:
    """Core reasoning engine for the HackerRank Orchestrate Support Triage Agent.
    
    Coordinates the pipeline: sanitization, intent classification, domain routing,
    lexical retrieval, escalation checks, and response generation.
    """
    
    def __init__(self, data_dir: Path) -> None:
        """Initialize the agent with a pre-loaded document corpus."""
        self.docs = load_corpus(data_dir)
        self.retriever = Retriever(self.docs)

    def triage(self, row: dict[str, str]) -> dict[str, str]:
        """Process a single support ticket and determine the appropriate action.
        
        Args:
            row: A dictionary containing 'issue', 'subject', and 'company'.
            
        Returns:
            A dictionary conforming to the output schema:
            {'status', 'product_area', 'response', 'justification', 'request_type'}
        """
        ticket = sanitize_row(row)
        text = ticket.text
        domain, route_confidence, route_reason = route_company(ticket.company, text)
        multi_intent, intent_note = detect_multi_intent(text)
        harmful = detect_harmful(text)
        request_type = classify_request_type(text, domain)

        hits = self.retriever.search(text, domain=domain, k=5) if domain else self.retriever.search(text, k=5)
        top = hits[0] if hits else None
        product_area = area_override(text, domain, top.doc.product_area if top else "")
        decision = escalation_guard(text, domain, request_type, top, route_confidence, multi_intent)

        if decision.invalid:
            if not domain or request_type == "invalid":
                product_area = "conversation_management" if product_area else ""
            result = self._invalid(product_area, decision.reason, decision.confidence, unsafe=harmful)
            if intent_note:
                result["justification"] += f" {intent_note}"
            return validate_output(result)
        if decision.escalate:
            if not domain:
                product_area = ""
            result = self._escalate(product_area, request_type, decision.reason, top, text, decision.confidence)
            if intent_note:
                result["justification"] += f" {intent_note}"
            return validate_output(result)
        result = self._reply(domain or "", product_area, request_type, hits, text, decision.confidence, route_reason)
        if harmful:
            result["response"] = "I can't assist with harmful or violent instructions. " + result["response"]
            result["justification"] += " Unsafe content was refused while the safe support intent was handled."
        if ticket.adversarial:
            result["justification"] += " Prompt-injection-like text was ignored as untrusted ticket data."
        if intent_note:
            result["justification"] += f" {intent_note}"
        return validate_output(result)

    def _invalid(self, product_area: str, reason: str, confidence: float = 0.0, unsafe: bool = False) -> dict[str, str]:
        response = "I am sorry, this is out of scope for this support agent. I can help with HackerRank, Claude, or Visa support questions grounded in the provided help corpus."
        if unsafe:
            response = "I can't assist with harmful or violent instructions. I can still help with HackerRank, Claude, or Visa support questions grounded in the provided help corpus."
        return {
            "status": "replied",
            "product_area": product_area,
            "response": response,
            "justification": f"{reason or 'The ticket is unrelated to the supported support domains.'} Confidence={confidence:.2f}.",
            "request_type": "invalid",
        }

    def _escalate(self, product_area: str, request_type: str, reason: str, hit: Hit | None, text: str, confidence: float) -> dict[str, str]:
        citation = ""
        hard_rule_reasons = {"account authority", "billing refund", "legal dispute", "security", "sitewide outage", "Ambiguous outage report without enough product context."}
        reason_detail = {
            "account authority": "The request asks for account, score, or access changes that require identity, role, or owning-organization verification beyond automated support.",
            "billing refund": "The request involves a refund, billing, or payment-specific outcome that requires secure account review before any action can be taken.",
            "legal dispute": "The request includes legal or merchant-dispute demands that require human review and cannot be resolved by an automated support response.",
            "security": "The issue involves security, compromise, or unauthorized activity and needs secure investigation beyond automated support.",
            "sensitive data export": "The request involves organization data export, which requires admin authorization and secure human review.",
            "sitewide outage": "The report describes a broad service outage rather than a single documented self-service workflow.",
            "Ambiguous outage report without enough product context.": "The report is too ambiguous to route safely because it lacks a supported product context.",
        }.get(reason, reason)
        if hit and reason not in hard_rule_reasons and reason != "sensitive data export":
            phrase = self.retriever.evidence_phrase(hit, text)
            citation = f" Nearest chunk {hit.doc.path} ('{hit.doc.title}') says: \"{phrase}\"."
        elif reason in hard_rule_reasons or reason == "sensitive data export":
            citation = " Hard escalation rule applied before answer generation."
        return {
            "status": "escalated",
            "product_area": product_area,
            "response": "Escalate to a human support specialist. This case needs account-specific review or carries risk that should not be resolved by an automated agent.",
            "justification": f"Escalated because {reason_detail.rstrip('.')}. Confidence={confidence:.2f}.{citation}".strip(),
            "request_type": request_type,
        }

    def _reply(
        self,
        domain: str,
        product_area: str,
        request_type: str,
        hits: list[Hit],
        text: str,
        confidence: float,
        route_reason: str,
    ) -> dict[str, str]:
        lower = text.lower()
        if domain == "visa":
            response = self._visa_response(lower, hits)
        elif domain == "claude":
            response = self._claude_response(lower, hits)
        else:
            response = self._hackerrank_response(lower, hits)
        top = self._evidence_hit(domain, lower, hits)
        if top:
            evidence_query = text
            if domain == "hackerrank" and any(term in lower for term in ("infosec", "security process", "security forms", "filling in the forms")):
                evidence_query = "need assistance HackerRank for Work support options submit request email support"
            if domain == "hackerrank" and _match(lower, _INACTIVITY_TERMS):
                evidence_query = "session inactivity timeout inactive sessions automatically log out default timeout"
            if domain == "hackerrank" and ("zoom connectivity" in lower or "compatible check" in lower):
                evidence_query = "verify system compatibility compatibility problems contact support screenshot error message"
            if domain == "hackerrank" and "reschedul" in lower:
                evidence_query = "HackerRank not authorized to reschedule assessments candidate contact recruiter hiring team"
            if domain == "hackerrank" and _match(lower, _REMOVAL_TERMS):
                evidence_query = "remove deactivate user roles management admin settings hackerrank for work"
            if domain == "hackerrank" and _match(lower, _RESUME_TERMS):
                evidence_query = "resume builder community profile create professional resume steps"
            if domain == "claude" and _match(lower, _BEDROCK_TERMS):
                evidence_query = "Claude Amazon Bedrock API requests failing configuration model access IAM permissions"
            if domain == "hackerrank" and "certificate" in lower and ("name" in lower or "update" in lower):
                evidence_query = "update name certificate certifications faqs once per account"
            phrase = self.retriever.evidence_phrase(top, evidence_query)
            grounding = f"Grounded in chunk {top.doc.path} ('{top.doc.title}'), which says: \"{phrase}\"."
        else:
            grounding = "Grounded in the support corpus."
        # Low-confidence softening: borderline replies acknowledge uncertainty naturally
        if confidence < 0.72 and not response.lower().startswith(("i cannot", "i can't", "do not", "report", "based on", "for a ", "visa")):
            response = "Based on available documentation, " + response[0].lower() + response[1:]
        return {
            "status": "replied",
            "product_area": product_area,
            "response": response,
            "justification": f"{grounding} Route={route_reason}. Confidence={confidence:.2f}.",
            "request_type": request_type,
        }

    def _evidence_hit(self, domain: str, lower: str, hits: list[Hit]) -> Hit | None:
        if domain == "hackerrank" and any(term in lower for term in ("infosec", "security process", "security forms", "filling in the forms")):
            support_hits = self.retriever.search("Contact HackerRank Support support@hackerrank.com account manager assistance", domain="hackerrank", k=3)
            for hit in support_hits:
                if "contact-us" in hit.doc.path or "contact" in hit.doc.title.lower():
                    return hit
        if domain == "hackerrank" and "reschedul" in lower:
            experience_hits = self.retriever.search("HackerRank not authorized reschedule assessments contact recruiter hiring team", domain="hackerrank", k=5)
            for hit in experience_hits:
                if "candidate-experience" in hit.doc.path:
                    return hit
            return experience_hits[0] if experience_hits else None
        if domain == "hackerrank" and ("zoom connectivity" in lower or "compatible check" in lower):
            compatibility_hits = self.retriever.search("verify system compatibility compatibility problems contact support screenshot error message", domain="hackerrank", k=5)
            for hit in compatibility_hits:
                if "audio-and-video-calls" in hit.doc.path or "compatibility" in hit.doc.title.lower():
                    return hit
            return compatibility_hits[0] if compatibility_hits else None
        if domain == "hackerrank" and any(term in lower for term in ("inactivity", "inactive", "kicked out", "sent back to the hr lobby")):
            timeout_hits = self.retriever.search("session inactivity timeout inactive sessions automatically log out default timeout", domain="hackerrank", k=5)
            for hit in timeout_hits:
                if "enhancing-your-account-security" in hit.doc.path:
                    return hit
            return timeout_hits[0] if timeout_hits else None
        if domain == "hackerrank" and ("test link expired" in lower or "tests stay active" in lower or "reinvite" in lower):
            test_hits = self.retriever.search("test expiration reinvite candidate active tests expire", domain="hackerrank", k=5)
            for hit in test_hits:
                if "expiration" in hit.doc.path or "reinviting" in hit.doc.path:
                    return hit
            return test_hits[0] if test_hits else None
        if domain == "hackerrank" and any(term in lower for term in ("remove an interviewer", "employee has left", "remove them from", "remove them")):
            roles_hits = self.retriever.search("remove deactivate user roles management admin hackerrank for work", domain="hackerrank", k=5)
            for hit in roles_hits:
                if "roles-management" in hit.doc.path or "user" in hit.doc.title.lower():
                    return hit
            return roles_hits[0] if roles_hits else None
        if domain == "hackerrank" and "resume builder" in lower:
            resume_hits = self.retriever.search("resume builder community profile create professional", domain="hackerrank", k=5)
            for hit in resume_hits:
                if "resume" in hit.doc.path or "resume" in hit.doc.title.lower():
                    return hit
            return resume_hits[0] if resume_hits else None
        if domain == "hackerrank" and "certificate" in lower and ("name" in lower or "update" in lower):
            cert_hits = self.retriever.search("update name certificate certifications faqs once per account", domain="hackerrank", k=5)
            for hit in cert_hits:
                if "certifications" in hit.doc.path or "certificate" in hit.doc.title.lower():
                    return hit
            return cert_hits[0] if cert_hits else None
        if domain == "claude" and _match(lower, _BEDROCK_TERMS):
            bedrock_hits = self.retriever.search("Claude Amazon Bedrock API requests failing configuration model access", domain="claude", k=5)
            for hit in bedrock_hits:
                if "bedrock" in hit.doc.path or "bedrock" in hit.doc.title.lower():
                    return hit
            return bedrock_hits[0] if bedrock_hits else None
        if domain == "visa" and any(term in lower for term in ("suspicious call", "otp", "scam")):
            fraud_hits = self.retriever.search("suspicious fraud report card issuer contact", domain="visa", k=5)
            for hit in fraud_hits:
                if "fraud" in hit.doc.path or "fraud" in hit.doc.title.lower():
                    return hit
            return fraud_hits[0] if fraud_hits else None
        if domain == "visa" and any(term in lower for term in ("blocked", "unblock", "ne marche", "voyage")):
            travel_hits = self.retriever.search("travel support blocked card issuer emergency assistance", domain="visa", k=5)
            for hit in travel_hits:
                if "travel-support" in hit.doc.path:
                    return hit
            return travel_hits[0] if travel_hits else None
        return hits[0] if hits else None

    def _hackerrank_response(self, lower: str, hits: list[Hit]) -> str:
        if "reschedul" in lower:
            return "HackerRank support cannot reschedule an employer assessment directly. Contact the recruiter or hiring company that invited you and ask them to reopen or resend the test invitation."
        if "regrade" in lower or "tell them i passed" in lower or "score is too low" in lower:
            return "HackerRank cannot change an assessment score or tell a hiring company to advance a candidate. For the separate account-deletion request, use the HackerRank Community account settings or contact the appropriate HackerRank support channel."
        if "payment" in lower and "change my email" in lower:
            return "For the payment issue, check the billing or mock-interview payment flow and contact HackerRank support if money was deducted without credits being applied. For the email change, use account settings if you still have access, or contact support because lost-email cases require account verification."
        if "test link expired" in lower or "tests stay active" in lower or "reinvite" in lower:
            return "Tests can remain active unless expiration settings are configured. If a candidate needs another attempt or the link no longer works, a recruiter can review the test settings and reinvite the candidate where allowed."
        if "zoom connectivity" in lower or "compatible check" in lower:
            return "Run the HackerRank system check again, confirm browser camera/microphone permissions, network access, and Zoom connectivity, then retry the assessment. If the check still fails, share the compatibility-check result with the test owner or HackerRank support."
        if _match(lower, _REMOVAL_TERMS):
            return "A company admin can remove or deactivate a user by going to HackerRank for Work → Settings → Users & Roles, selecting the user, and choosing the remove or deactivate option. If the option is not visible, confirm you have admin-level permissions or ask your account admin to make the change."
        if "pause our subscription" in lower:
            return "Subscription changes are billing/account-specific. A human support or account-management specialist should review whether pausing, canceling, or changing the plan is available for your contract."
        if "infosec" in lower or "security questionnaire" in lower or "security review" in lower:
            return "For procurement or information-security reviews, contact HackerRank support or your account team with the required questionnaire and deadline so the right team can provide approved security documentation."
        if "apply tab" in lower or "quick apply" in lower:
            return "For HackerRank Community job-application issues, ensure you are signed in to the correct account and navigate to the Jobs section, then select the Apply tab. If the tab is still not visible, contact HackerRank support with a screenshot and your account email for further review."
        if _match(lower, _INACTIVITY_TERMS):
            return "HackerRank for Work Company Admins can configure the session inactivity timeout under Settings → Security. The timeout applies to both candidates and interviewers. If users are being returned to the lobby sooner than expected, a Company Admin can review and extend the timeout setting, or contact HackerRank support with the session details for investigation."
        if _match(lower, _RESUME_TERMS):
            return "The HackerRank Resume Builder is accessible from your Community profile. If it is currently unavailable or not loading, try refreshing the page or clearing your browser cache. If the issue persists, contact HackerRank support with your account email and a description of the problem."
        if "certificate" in lower and ("name" in lower or "incorrect" in lower or "update" in lower):
            return "You can update the name on your HackerRank certificate once per account through your Community profile settings. After updating, the change applies to all certificates. Navigate to your profile, select the name-update option, and confirm the change."
        return self._corpus_fallback("HackerRank", hits)

    def _claude_response(self, lower: str, hits: list[Hit]) -> str:
        if _match(lower, _CRAWL_TERMS):
            return "Anthropic provides documentation about its web crawling and how site owners can learn more or block crawlers. Review the Anthropic privacy and legal guidance for site-owner controls, then add the appropriate robots.txt or meta-tag directives to your site."
        if _match(lower, _DATA_IMPROVE_TERMS):
            return "Claude privacy documentation explains data controls and retention by plan. Review the relevant privacy or plan article for how model-improvement settings affect submitted data, and adjust the setting in your account or organization controls if needed."
        if _match(lower, _BEDROCK_TERMS):
            return "For Claude on Amazon Bedrock failures, check the Bedrock-specific Claude documentation, your request configuration, and model availability in the AWS region you are using. Verify your IAM permissions and Bedrock model access are correctly set up. If all requests are still failing, collect the error messages and contact Amazon Bedrock support or Anthropic support through the appropriate channel."
        if "lti" in lower or "canvas" in lower or "learning management" in lower:
            return "Claude for Education includes LTI setup guidance for university admins. Use the Claude LTI documentation to configure the integration in your learning-management system and coordinate required admin credentials."
        if "unsupported region" in lower or "bypass" in lower or "not available in my region" in lower:
            return "I cannot bypass regional or access restrictions. Check the Claude API and Console availability documentation and use the normal access or support process for your region and account."
        if "private messages" in lower or "private info" in lower or "stop using my chats" in lower:
            return "I cannot view private messages. For privacy-related Claude chats, use the documented conversation controls to delete or manage chats, and review account data settings for model-improvement preferences."
        if "voice mode" in lower or "voice feature" in lower:
            return "Voice mode is documented as a Claude mobile feature. If it is not appearing, update the app, confirm your platform supports the feature, and check the Claude mobile guidance for current availability."
        return self._corpus_fallback("Claude", hits)

    def _visa_response(self, lower: str, hits: list[Hit]) -> str:
        # Multilingual and paraphrased travel/blocked card — catch first
        if _match(lower, _TRAVEL_CARD_TERMS):
            return "For a blocked or restricted Visa card while traveling, contact your card issuer immediately using the number on the back of your card or the issuer's official website. Only the card issuer can unblock the card, arrange a replacement, or provide emergency cash assistance through the Visa Global Customer Assistance Service."
        if "suspicious call" in lower or "otp" in lower or "scam" in lower or "scam call" in lower:
            return "Do not share OTPs, passwords, or card details with an unsolicited caller. Contact the issuer using the number on your card or official banking app, monitor recent activity, and report the suspicious contact if your issuer provides that option."
        if "cash" in lower:
            return "Visa cards can generally be used at ATMs or financial institutions that accept Visa for cash access, subject to issuer rules, available credit/funds, fees, and local limits. Contact your card issuer for urgent cash options."
        if "fake item" in lower or "merchant shipped" in lower or "wrong item" in lower or "wrong product" in lower:
            return "Visa itself does not directly ban a merchant or issue an immediate refund from this support request. Contact the card issuer or financial institution that provided your card so they can review whether a transaction dispute or chargeback process applies."
        if "dispute" in lower or "charge" in lower or "chargeback" in lower:
            return "For a Visa transaction dispute, contact the financial institution or issuer that provided your card. The issuer can review the transaction, explain dispute rights, and start any chargeback process that applies."
        if "lost or stolen" in lower or "stolen visa card" in lower:
            return "Report a lost or stolen Visa card to your card issuer immediately. The issuer can block the card, review recent activity, and arrange replacement or emergency assistance if available."
        if "minimum" in lower or "minimum spend" in lower or "minimum amount" in lower:
            return "Visa rules generally prohibit merchants from setting a minimum transaction amount for Visa credit or debit acceptance unless local rules allow it. Contact your card issuer or Visa support with merchant details if you believe a merchant is applying an improper minimum."
        return self._corpus_fallback("Visa", hits)

    def _corpus_fallback(self, domain_name: str, hits: list[Hit]) -> str:
        import re as _re
        if not hits:
            return f"I could not find enough {domain_name} documentation to answer confidently. Please contact {domain_name} support directly for further assistance."
        snippet = hits[0].snippet
        # Regex-based stripping: handles inline markdown headers, metadata, and
        # bold markers that appear mid-string (line-based splitting misses these).
        clean = _re.sub(r'#+ ', '', snippet)                                  # markdown headers
        clean = _re.sub(r'_Last (?:updated|modified):[^_]*_', '', clean)       # date metadata
        clean = _re.sub(r'source_url:\S+', '', clean)                          # source URLs
        clean = _re.sub(r'\*\*', '', clean)                                    # bold markers
        clean = _re.sub(r'\s{2,}', ' ', clean).strip()                         # collapse whitespace
        words = clean.split()
        compact = " ".join(words[:55]) if words else snippet[:300]
        response = f"Based on {domain_name} support documentation: {compact}."
        # Action-step guard: every response must tell the user what to do next
        action_words = ("contact", "visit", "go to", "navigate", "select", "check", "review", "use", "click", "open", "submit")
        if not any(w in response.lower() for w in action_words):
            response += f" If this does not resolve the issue, contact {domain_name} support directly with your account details."
        else:
            response += f" Follow that workflow and contact {domain_name} support if the issue remains unresolved."
        return response
