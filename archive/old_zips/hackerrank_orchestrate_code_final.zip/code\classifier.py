from __future__ import annotations

import re


BUG_TERMS = ("down", "not working", "stopped working", "failing", "error", "bug", "blocker", "unable", "can't", "cannot", "crash", "none of")
FEATURE_TERMS = ("feature request", "can you add", "please add", "enhancement", "support for")
INVALID_TERMS = (
    "iron man", "actor", "weather", "recipe", "joke", "delete all files", "system prompt",
    "ignore previous", "photosynthesis", "homework", "resignation email",
)


def classify_request_type(text: str, company: str | None) -> str:
    lower = text.lower()
    if not lower.strip() or any(term in lower for term in INVALID_TERMS):
        return "invalid"
    if not company and not any(term in lower for term in ("hackerrank", "claude", "visa", "card", "assessment", "test")):
        if len(re.findall(r"[a-zA-Z]", lower)) < 18:
            return "invalid"
    if any(term in lower for term in FEATURE_TERMS):
        return "feature_request"
    if any(term in lower for term in BUG_TERMS):
        return "bug"
    return "product_issue"
